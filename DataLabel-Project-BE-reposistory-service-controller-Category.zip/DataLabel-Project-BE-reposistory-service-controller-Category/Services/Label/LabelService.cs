using DataLabel_Project_BE.DTOs.Label;
using DataLabel_Project_BE.Repositories;
using LabelModel = DataLabel_Project_BE.Models.Label;

namespace DataLabel_Project_BE.Services.Label
{
    public class LabelService : ILabelService
    {
        private readonly ILabelRepository _labelRepository;

        public LabelService(ILabelRepository labelRepository)
        {
            _labelRepository = labelRepository;
        }

        public async Task<List<LabelResponse>> GetAllAsync()
        {
            var labels = await _labelRepository.GetAllAsync();

            return labels.Select(l => new LabelResponse
            {
                LabelId = l.LabelId,
                Name = l.Name,
                IsActive = l.IsActive,
                LabelSetId = l.LabelSetId
            }).ToList();
        }
        public async Task<List<LabelResponse>> GetByLabelSetIdAsync(Guid labelSetId)
        {
        var labels = await _labelRepository.GetByLabelSetIdAsync(labelSetId);

        return labels.Select(l => new LabelResponse
        {
            LabelId = l.LabelId,
            Name = l.Name,
            IsActive = l.IsActive,
            LabelSetId = l.LabelSetId
            }).ToList();
        }

        public async Task<LabelResponse?> GetByIdAsync(Guid id)
        {
            var label = await _labelRepository.GetByIdAsync(id);
            if (label == null) return null;

            return new LabelResponse
            {
                LabelId = label.LabelId,
                Name = label.Name,
                IsActive = label.IsActive,
                LabelSetId = label.LabelSetId
            };
        }

        public async Task<LabelResponse> CreateAsync(CreateLabelRequest request)
        {
            var label = new LabelModel
            {
                LabelId = Guid.NewGuid(),
                Name = request.Name,
                LabelSetId = request.LabelSetId,
                IsActive = true
            };

            await _labelRepository.CreateAsync(label);

            return new LabelResponse
            {
                LabelId = label.LabelId,
                Name = label.Name,
                IsActive = label.IsActive,
                LabelSetId = label.LabelSetId
            };
        }

        public async Task<bool> UpdateAsync(Guid id, UpdateLabelRequest request)
        {
            var label = await _labelRepository.GetByIdAsync(id);
            if (label == null) return false;

            label.Name = request.Name;
            label.IsActive = request.IsActive;

            await _labelRepository.UpdateAsync(label);
            return true;
        }

        public async Task<bool> DeleteAsync(Guid id)
        {
            var label = await _labelRepository.GetByIdAsync(id);
            if (label == null) return false;

            label.IsActive = false;
            await _labelRepository.UpdateAsync(label);
            return true;
        }
    }
}
