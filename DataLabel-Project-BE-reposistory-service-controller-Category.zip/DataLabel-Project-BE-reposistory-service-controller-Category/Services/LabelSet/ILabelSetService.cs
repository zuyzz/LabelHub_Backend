using DataLabel_Project_BE.DTOs.LabelSet;

namespace DataLabel_Project_BE.Services.LabelSet;

public interface ILabelSetService
{
    Task<List<LabelSetResponse>> GetAllAsync();
    Task<LabelSetResponse> CreateAsync(CreateLabelSetRequest request, Guid? createdBy);
    Task<LabelSetResponse?> CreateNewVersionAsync(Guid labelSetId, UpdateLabelSetRequest request, Guid? createdBy);
}
