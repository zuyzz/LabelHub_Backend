namespace DataLabel_Project_BE.DTOs.Label;

public class CreateLabelRequest
{
    public Guid LabelSetId { get; set; }
    public string Name { get; set; } = null!;
}
