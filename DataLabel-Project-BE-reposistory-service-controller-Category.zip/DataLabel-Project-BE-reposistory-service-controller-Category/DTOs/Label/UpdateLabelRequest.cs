namespace DataLabel_Project_BE.DTOs.Label;

public class UpdateLabelRequest
{
    public string Name { get; set; } = null!;
    public bool IsActive { get; set; }
}
