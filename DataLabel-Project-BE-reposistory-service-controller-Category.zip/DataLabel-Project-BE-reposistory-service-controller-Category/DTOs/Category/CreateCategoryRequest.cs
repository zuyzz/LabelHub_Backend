namespace DataLabel_Project_BE.DTOs.Category;

public class CreateCategoryRequest
{
    public string Name { get; set; } = null!;
    public string? Description { get; set; }
}
