using DataLabel_Project_BE.Models;

namespace DataLabel_Project_BE.Repositories
{
    public interface ILabelRepository
    {
        Task<List<Label>> GetAllAsync();
        Task<Label?> GetByIdAsync(Guid id);
        Task<List<Label>> GetByLabelSetIdAsync(Guid labelSetId); 
        Task CreateAsync(Label label);
        Task UpdateAsync(Label label);
    }
}