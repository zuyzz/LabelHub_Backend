namespace DataLabel_Project_BE.DTOs
{
    public enum JoinProjectResult
    {
        Success,
        AlreadyMember,
        ProjectNotFound,
        Unauthorized,
        Forbidden
    }
}