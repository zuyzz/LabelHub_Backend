namespace DataLabel_Project_BE.DTOs.Label;

public class LabelResponse
{
    public Guid LabelId { get; set; }
    public Guid LabelSetId { get; set; }
    public string Name { get; set; } = null!;
    public bool IsActive { get; set; }
}
