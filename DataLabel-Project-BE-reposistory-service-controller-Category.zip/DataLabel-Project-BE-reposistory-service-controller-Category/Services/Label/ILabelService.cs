using DataLabel_Project_BE.DTOs.Label;

namespace DataLabel_Project_BE.Services.Label
{
    public interface ILabelService
    {
        Task<List<LabelResponse>> GetAllAsync();
        Task<LabelResponse?> GetByIdAsync(Guid id);
        Task<List<LabelResponse>> GetByLabelSetIdAsync(Guid labelSetId); // 👈 CÁI NÀY
        Task<LabelResponse> CreateAsync(CreateLabelRequest request);
        Task<bool> UpdateAsync(Guid id, UpdateLabelRequest request);
        Task<bool> DeleteAsync(Guid id);
    }
}
