using DataLabel_Project_BE.DTOs.Label;
using DataLabel_Project_BE.Services.Label;
using Microsoft.AspNetCore.Mvc;

namespace DataLabel_Project_BE.Controllers;

[ApiController]
[Route("api/labels")]
public class LabelsController : ControllerBase
{
    private readonly ILabelService _service;

    public LabelsController(ILabelService service)
    {
        _service = service;
    }

    [HttpGet("label-set/{labelSetId}")]
    public async Task<IActionResult> GetByLabelSet(Guid labelSetId)
        => Ok(await _service.GetByLabelSetIdAsync(labelSetId));

    [HttpPost]
    public async Task<IActionResult> Create(CreateLabelRequest req)
        => Ok(await _service.CreateAsync(req));

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(Guid id, UpdateLabelRequest req)
        => await _service.UpdateAsync(id, req) ? Ok() : NotFound();

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(Guid id)
        => await _service.DeleteAsync(id) ? Ok() : NotFound();
}
