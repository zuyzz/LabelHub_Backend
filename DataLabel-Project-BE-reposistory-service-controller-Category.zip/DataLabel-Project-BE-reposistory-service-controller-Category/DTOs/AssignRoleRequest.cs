namespace DataLabel_Project_BE.DTOs
{
    public class AssignRoleRequest
    {
        public Guid RoleId { get; set; }
        // public string RoleName { get; set; } = string.Empty;
    }
}
